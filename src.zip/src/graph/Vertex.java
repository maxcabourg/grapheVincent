package graph;

/**
 * Represente un sommet du graphe
 * @author max.cabourg
 *
 */
public class Vertex {
	
	private int indice;
	private boolean estFranchissable;
	
	
	/**
	 * Constructeur par defaut
	 */
	public Vertex()
	{
		
	}
	
	/**
	 * Construit un Vertex a partir d'un indice
	 * @param numero L'indice a attribuer
	 */
	public Vertex(int numero)
	{
		indice = numero;
	}
	
	public void setIndice(int numero)
	{
		indice = numero;
	}

	public int getIndice()
	{
		return indice;
	}

	public boolean isEstFranchissable() {
		return estFranchissable;
	}

	public void setEstFranchissable(boolean estFranchissable) {
		this.estFranchissable = estFranchissable;
	}
	
	
}
