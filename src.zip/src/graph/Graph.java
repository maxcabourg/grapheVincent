package graph;

/**
 * Specifications fonctionnelles d'un graphe avec un vertex d'arrivee et de depart
 * @author max.cabourg
 *
 */
public interface Graph {

	void construireGrille();
	/**
	*Ajoute un vertex au graphe
	*@param v vertex à ajouter
	*/
	void addVertex(Vertex v);
	/**
	* Ajoute une arete au graphe
	* @param e l'arete a ajouter au graphe
	*/
	void addEdge(Edge e);

	/**
	* Indique si une certaine arete est presente dans le graphe
	* @param e L'arete a detecter
	* @return true si l'arete existe bien dans le graphe, false sinon
	*/
	boolean containsEdge(Edge e);

	/**
	* Indique si un certain vertex est present dans le graphe
	* @param v Le vertex a detecter
	* @return true si le vertex existe bien dans le graphe, false sinon
	*/
	boolean containsVertex(Vertex v);

	/**
	* Renvoie les vertex voisins a un certain vertex, ie relies par une arete
	* @param v Le vertex dont on souhaite avoir les voisins
	* @return Un tableau contenant les voisins de ce vertex
	*/
	Vertex[] getNeighboors(Vertex v);

	/**
	* Retire le vertex du graphe
	*@param v Le vertex a retirer
	*/
	void removeVertex(Vertex v);

	/**
	* Retire l'arete du graphe
	* @param e l'arete a retirer
	*/
	void removeEdge(Edge e);

	/**
	* Renvoie le nombre de sommets du graphe
	*/
	int getNumberOfVertices();

	/**
	* Renvoie le nombre d'aretes du graphe
	*/
	int getNumberOfEdges();


}
