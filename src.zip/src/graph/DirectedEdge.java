package graph;

/**
 * Arete orientee
 * @author max.cabourg
 *
 */
public class DirectedEdge extends Edge{	
	/**
	* Definit le vertex d'arrivee et de depart de l'arete
	*@param v1 vertex de depart
	*@param v2 vertex d'arrivee
	*/
	public void definirExtremites(Vertex v1, Vertex v2) {
		// TODO Auto-generated method stub
		this.v1 = v1;
		this.v2 = v2;	
	}
	
	/**
	* Constructeur par defaut
	*/
	public void DirectedEdge()
	{
		
	}
}
