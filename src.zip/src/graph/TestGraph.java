package graph;

public class TestGraph {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vertex v = new Vertex(0);
		Edge e = new DirectedEdge();
	}

}
