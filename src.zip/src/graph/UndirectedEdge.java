package graph;

/**
*Classe representant une arete non orientee dans un graphe
*@author Max Cabourg et Vincent Guerin
*/
public class UndirectedEdge extends Edge{

	public UndirectedEdge(Vertex v1, Vertex v2) {
		super();
		this.v1 = v1;
		this.v2 = v2;
	}

	@Override
	public void definirExtremites(Vertex v1, Vertex v2) {
		// TODO Auto-generated method stub
		this.v1 = v1;
		this.v2 = v2;
		
	}
	
	
}
